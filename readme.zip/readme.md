######################## HOW TO RUN THE PROGRAM ###################################

install pandas, matplotlib, numpy and seaborn

using either conda or pip

$ conda install pandas, matplotlib, numpy, seaborn

or 

$ pip install pandas, matplolib, numpy, seaborn


After installation
* Go to project directory
* run on the terminal, cmd or anaconda command prompt using

$ python main.py

$ python credit.py